package com.nobroker.Test;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class Nobrokerapp 
{

	WebDriver driver;
	WebDriverWait wait;
	
	
	DesiredCapabilities dc = new DesiredCapabilities();
	
	ExtentReports er=new ExtentReports("Nobroker.html",false);
	ExtentTest et=er.startTest("Nobroker App");
	
	
	public void nobrokerapp()  throws Exception
	{
		
		
		dc.setCapability("deviceName", "4200deb4b2221400");
		dc.setCapability("platformName", "Android");
		dc.setCapability("platformVersion", "6.0.1");
		dc.setCapability("appPackage", "com.nobroker.app");
		dc.setCapability("automationname","UiAutomator1");
		dc.setCapability("appActivity","com.nobroker.app.activities.NBSplashScreen");
		
		
		//Appium server
		Runtime.getRuntime().exec("cmd.exe /c start cmd.exe /k \"appium -a 0.0.0.0 -p 4723\"");
	    URL u=new URL ("http://0.0.0.0:4723/wd/hub");
		
		
	  //driver object
		 AndroidDriver driver = null;
		 while(2>1)
		 {
			try
			{
			driver=new AndroidDriver(u,dc);
			break;	
		    }
		       catch(Exception ex)
		            {
			             System.out.print(ex.getMessage());
		              }
	     
		 }//while close
		
		 driver.manage().timeouts().implicitlyWait(25,TimeUnit.SECONDS);
	
		 //Allow permissions for Deviceloca/Phncalls/contacts
		 driver.findElement(By.xpath("//*[@ text='Continue']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@ text='Allow']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@ text='Allow']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@ text='Allow']")).click();
		 
		 driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		 
		 //Login Application
		//Enter Login credentials for Nobroker app
		 File f=new File("F:\\wil_workspace\\Appiumnobroker\\src\\main\\java\\com\\nobroker\\testdata\\Nobroker data.xls");
   		 Workbook rwb=Workbook.getWorkbook(f);
   		 Sheet rsh=rwb.getSheet("Nobrokerlogincred");
   		 int nour=rsh.getRows();
   		 System.out.println("No of Rows in Nobroker logincredentials  Sheet\t -   " + nour);
   		 
   		 //Open Excel File for Writing results
		 File f1=new File("F:\\wil_workspace\\Appiumnobroker\\src\\main\\java\\com\\nobroker\\reports\\Nobroker report.xls");
		 Workbook rwb1=Workbook.getWorkbook(f1);
		 WritableWorkbook wwb1=Workbook.createWorkbook(f1,rwb1);
		 WritableSheet wsh1=wwb1.getSheet("logincredresults"); 
         
		 //create result columns
		 int nouc=wsh1.getColumns();
		 
		 
		 //Take Results Heading as date and Time Format
		 Date d=new Date();
		 SimpleDateFormat sf=new SimpleDateFormat(" dd-MM-yyyy-hh-mm-ss ");
		 String cname=" Results on "+sf.format(d);
	 	 //set name to result column in LoginSheet
		 Label l1=new Label(nouc,0,cname);
		 wsh1.addCell(l1);
		 //columns
	     
	     WritableFont wf=null;
	     WritableCellFormat cf=null;
	     wf=new WritableFont(WritableFont.ARIAL,10,WritableFont.BOLD);
	     wf.setColour(Colour.GREEN);
	     cf=new WritableCellFormat(wf);
	     cf.setAlignment(Alignment.JUSTIFY);
	     cf.setWrap(true);
	
	   
	    
	     
		 //Click on Menu	
		 driver.findElement(By.xpath("//*[@content-desc='Navigate up']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 //Click on Login/Signup 
		 driver.findElement(By.xpath("//*[@text='LOGIN/SIGNUP']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 //Enter the Phone number 
		 driver.findElement(By.xpath("//*[@text='Enter Phone Number']")).sendKeys(rsh.getCell(0,1).getContents());
		 //Thread.sleep(90000);
		 wait = new WebDriverWait(driver,100);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@resource-id='com.nobroker.app:id/rb_signup_pwd']")));
		 //Select Password option
		 driver.findElement(By.xpath("//*[@resource-id='com.nobroker.app:id/rb_signup_pwd']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 //Enter the password		 
		 driver.findElement(By.xpath("//*[@text='Enter Password']")).sendKeys(rsh.getCell(1,1).getContents());
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Hide keyboard
		 driver.hideKeyboard();
		 Thread.sleep(2000);
		 //Click on continue
		 driver.findElement(By.xpath("//*[@text='Continue']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		 //Select Buy option and click on search box
		 driver.findElement(By.xpath("//*[@text='Buy']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 
		 //Select Bangalore city
		 driver.findElement(By.xpath("//*[@text='Bangalore']")).click();
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@text='Bangalore']")).click();
		 
		 /*Select s = new Select(driver.findElement(By.xpath("//*[@resource-id='android:id/text1']")));
		 s.selectByVisibleText("Bangalore");*/
		 
		//Select two localities
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).click();
		 File f2=new File("F:\\wil_workspace\\Appiumnobroker\\src\\main\\java\\com\\nobroker\\testdata\\Nobroker data.xls");
   		 Workbook rwb2=Workbook.getWorkbook(f2);
   		 Sheet rsh1=rwb2.getSheet("Locations");
   		 int nourows=rsh1.getRows();
   		 driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).sendKeys(rsh1.getCell(0,1).getContents());
   		 
   		 
  		 
   		 Thread.sleep(5000);
   		 //Here we need to click on location manually
   		 
   		 driver.findElement(By.xpath("//*[@text='Add locality,landmark']")).click();
   		 driver.findElement(By.xpath("//*[@text='Add locality,landmark']")).sendKeys(rsh1.getCell(1,1).getContents());
		 Thread.sleep(5000);
		//Here we need to click on location manually
		 
		 
   		
   		 
   		//driver.findElement(By.xpath("//*[@text='Marthahalli']")).getText();
   				 
   		 /*WebElement we = driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")); //sendKeys(rsh1.getCell(0,1).getContents());
   		 we.sendKeys(rsh1.getCell(0,1).getContents());
   		 
   		 int x = we.getLocation().getX();
   		 int y = we.getLocation().getY();
   		 
   		 System.out.println(" X value : " + x + " Y value : " + y);
   		 Thread.sleep(2000);*/
   		 
   		 /*AndroidTouchAction touch = new AndroidTouchAction(driver);
   		 touch.tap(TapOptions.tapOptions().withElement(ElementOption.element(e)).*/
   		 
   		 
   		/*Thread.sleep(3000);
   		driver.pressKeyCode(AndroidKeyCode.KEYCODE_PAGE_DOWN);
   		Thread.sleep(3000);
   		driver.pressKeyCode(AndroidKeyCode.KEYCODE_ENTER);
   		Thread.sleep(3000);
   		String text = driver.findElementById("com.nobroker.app:id/localityAutoCompleteTxt").getText();
   		System.out.println("Text Found : " + text);*/
   		
   				 
   		 
   		/*driver.pressKeyCode(KeyEvent.VK_DOWN);
  		 driver.pressKeyCode(KeyEvent.VK_ENTER);*/
   		 
   		 
   		 /*List<WebElement> list = driver.findElementById("com.nobroker.app:id/localityAutoCompleteTxt").getText();
   		 
   		 int size = list.size();
   		 
   		 System.out.println(size);*/
   		 
   		
   		
   		 
   		 
   		 
   		 
   		
        
   		 /*driver.findElement(By.xpath("//*[@text='Marthahalli']")).click();
   	     
		// driver.findElement(By.xpath("//*[@resource-id='com.nobroker.app:id/nearByRadio']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@text='Add locality,landmark']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@text='Add locality,landmark']")).sendKeys(rsh1.getCell(1,1).getContents());
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@resource-id='com.nobroker.app:id/fl_multiple_locations")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 */
		 
		 
		 
		 //Select two localities
		// driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).click();
		 /*File f2=new File("F:\\wil_workspace\\Appiumnobroker\\src\\main\\java\\com\\nobroker\\testdata\\Nobroker data.xls");
   		 Workbook rwb2=Workbook.getWorkbook(f2);
   		 Sheet rsh1=rwb2.getSheet("Locations");
   		 int nourows=rsh1.getRows();
   		 driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).sendKeys(rsh1.getCell(0,1).getContents());
		 Thread.sleep(5000);
		 Select s1 = new Select(driver.findElement(By.xpath("//*[@resource-id='com.nobroker.app:id/localityAutoCompleteTxt']")));
		 s1.selectByIndex(0);
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@text='Add locality,landmark']")).click();
		 driver.findElement(By.xpath("//*[@text='Search up to 3 Localities or Landmarks']")).sendKeys(rsh1.getCell(1,1).getContents());
		 Thread.sleep(5000);		 
		 Select s2 = new Select(driver.findElement(By.xpath("//*[@resource-id='com.nobroker.app:id/localityAutoCompleteTxt']")));
		 s1.selectByIndex(0);
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 //Select & Check the include nearby properties
		 driver.findElement(By.xpath("//*[@text='Include nearby properties']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 //Click on Search button
		 driver.findElement(By.xpath("//*[@text='Include nearby properties']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);*/
		 
   		 wait = new WebDriverWait(driver,20);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='Include nearby properties']")));
		 //Select check box near by properties
		 driver.findElement(By.xpath("//*[@text='Include nearby properties']")).click();
		 Thread.sleep(5000);
		 
		 //Click on search
		 driver.findElement(By.xpath("//*[@text='Search']")).click();
		 driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		 
		 
		 
		 
		 //Vertical Scroll and select 4th property
		 
		 /*TouchAction action = new TouchAction(driver);
		 Dimension size = driver.manage().window().getSize();
		 int width = size.width;
		 int height = size.height;
		 
		 System.out.println(" Width--------> " + width);
		 System.out.println(" Height-------> " + height);
		 
		 int middleOfx=width/2;
		 int startYCoordinate=(int)(height*.1280);
		 int endYCoordinate=(int)(height*.1280);
		 
		 action.press(PointOption.point(middleOfx,startYCoordinate))
		 .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
		 .moveTo(PointOption.point(middleOfx,endYCoordinate))
		 .release()
		 .perform();*/
		 
		 //Vertical scrolling
		// ((WebElement) driver.findElementsById("com.nobroker.app:id/searchProperty").get(1)).click();
		 
		 //Capture all the list items
		 AndroidElement list=(AndroidElement)driver.findElementsById("com.nobroker.app:id/property_thumbnail");
		 
		 //Scrolling down till we get the element
		 MobileElement listitem = (MobileElement)driver.findElement
				 (MobileBy.AndroidUIAutomator(
						 "new Uiscrollable(new Uiselector()).scrollintoview("
						 + "new Uiselector().description(\"Mahaveer Seasons, 24th Main Rd, ITI Layout, Sector 2, HSR Layout, Bengaluru, Karnataka 560102, India, Hsr Layout\"));"));;
				 
				 System.out.println(listitem.getLocation());
				 listitem.click();
		 Thread.sleep(3000);
		 
		/*driver.findElement(By.xpath("//*[@text='Mahaveer Seasons, 24th Main Rd, ITI Layout, Sector 2, HSR Layout, Bengaluru, Karnataka 560102, India, Hsr Layout']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);*/
		 
		//Scroll down to till end click on Wrong info 
		 
		 /*int middleOfx1=width/2;
		 int startYCoordinate1=(int)(height*.1280);
		 int endYCoordinate1=(int)(height*.1280);
		 
		 action.press(PointOption.point(middleOfx1,startYCoordinate1))
		 .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
		 .moveTo(PointOption.point(middleOfx1,endYCoordinate1))
		 .release()
		 .perform();*/
		 
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@text='Wrong Info']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 
		 //Select all check boxes what's wrong section
		 
		 driver.findElementById("com.nobroker.app:id/cb_location").click();
		 Thread.sleep(3000);
		 driver.findElementById("com.nobroker.app:id/cb_fake_photos").click();
		 Thread.sleep(3000);
		 driver.findElementById("com.nobroker.app:id/cb_bhk_type").click();
		 Thread.sleep(3000);
		 driver.findElementById("com.nobroker.app:id/cb_availability_date").click();
		 Thread.sleep(3000);
		 driver.findElementById("com.nobroker.app:id/cb_price").click();
		 Thread.sleep(3000);
		 driver.findElementById("com.nobroker.app:id/cb_other").click();
		 Thread.sleep(3000);
		 
		 //Click on Report
		 driver.findElement(By.xpath("//*[@text='Report']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 
		 //Change 3BHK to 4+BHK from ‘whats is the correct configuration’ section in “Suggest an Edit” page.	
		 	 
		 wait = new WebDriverWait(driver,30);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='Suggest an edit']")));
		 
		 driver.navigate().back();
		 Thread.sleep(2000);
		 //Hide keyboard
		 driver.hideKeyboard();
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@text='3 BHK']")).click();
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@text='4+ BHK']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 
		 
		 
		 
		 /*int middleOfx2=width/2;
		 int startYCoordinate2=(int)(height*.1);
		 int endYCoordinate2=(int)(height*.4);
		 
		 action.press(PointOption.point(middleOfx2,startYCoordinate2))
		 .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
		 .moveTo(PointOption.point(middleOfx2,endYCoordinate2))
		 .release()
		 .perform();*/
		 
		 //Entering Note
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@text='Add a note']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@text='Add a note']")).sendKeys("Testing");
		 //Hide keyboard
		 driver.hideKeyboard();
		 Thread.sleep(3000);
		 
		 //Click on save changes
		 
		 driver.findElement(By.xpath("//*[@text='Save Changes']")).click();
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 
		 wait = new WebDriverWait(driver,30);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='Thank you for the feedback']")));
		 System.out.println("Getting Successfull Feedback Message");
		 
		//Extent reports
		 et.log(LogStatus.PASS,"Nobroker app working successfully");
		 //Excel sheet
         Label l2=new Label(nouc,0,"Nobroker app working successfully");
         l2.setCellFormat(cf);
         wsh1.addCell(l2);
		 
           //Save Extent Results
			er.endTest(et);
			er.flush();
			//save Excel results
			wwb1.write();
		    rwb.close();
		    wwb1.close();
		    
	        //stop appium server
        // Runtime.getRuntime().exec("taskkill/f/IM node.exe"); 
        // Runtime.getRuntime().exec("taskkill/f/IM cmd.exe");
         
  

	
	} //Method close
		 
	     
		 
	}//Class close

	



