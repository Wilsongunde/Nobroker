package com.nobroker.Test;

import org.testng.annotations.Test;

public class Nobrokerapptest 
{
	
	@Test
	public void Apptest() throws Exception
	{
	
	Nobrokerapp app = new Nobrokerapp();
	
	app.nobrokerapp();
	
	}
	
}
